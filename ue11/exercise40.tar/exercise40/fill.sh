#!/bin/sh

N=$(tr -dC '[:xdigit:]' < $1 | wc -c)
N=$(($2 - $N / 2))
for i in $(seq 1 $N)
do
	echo -n "da"
done

