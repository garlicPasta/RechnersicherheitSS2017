#include <stdio.h>
#include <fcntl.h>

char* hello = "hello_world!\n";

typedef void (*fn_ptr)(void);

void bar(void){
  printf("does not do anything\n");
}

void foo(void){
  char buffer[1024];
  fn_ptr func = bar;

  if(read(0, buffer, 1024) > 10)
    func = (fn_ptr) buffer;

  func();
}

int main(){
  foo();
  return 0;
}
